self.__precacheManifest = [
  {
    "revision": "08aff79db06fba2cd842",
    "url": "./static/css/main.dcbe1d81.chunk.css"
  },
  {
    "revision": "08aff79db06fba2cd842",
    "url": "./static/js/main.08aff79d.chunk.js"
  },
  {
    "revision": "9edbc364ba1f25aee351",
    "url": "./static/js/1.9edbc364.chunk.js"
  },
  {
    "revision": "4a686d48d5a089750c49",
    "url": "./static/js/runtime~main.4a686d48.js"
  },
  {
    "revision": "e6b508671cc6bcc4000d0bce3d3a1650",
    "url": "./static/media/tuple.e6b50867.mjs"
  },
  {
    "revision": "641d8c3f4a905e08111bf2c775da0d7e",
    "url": "./index.html"
  }
];